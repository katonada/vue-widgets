<template>
  <div>
    <div :class="'ecom__wrap ecom__wrap--' + product.bundle">
      <div class="ecom__container">
        <!-- BEGIN VARIATIONS IMAGES (SLIDER) -->
        <div class="ecom__media">
          <Loader class="ecom__images-loader" />
          <div
            v-for="(variation, key, index) in product.variations"
            :key="index"
            class="ecom__images"
            :data-variation="variation.id"
          >
            <Slider v-show="activeImages.length && key == activeVariation" :images="activeImages" class="ecom__slider" />
          </div>
        </div>
        <!-- END VARIATIONS IMAGES (SLIDER) -->

        <div class="ecom__data">
          <Info :product="product" :activeVariation="activeVariation" class="ecom__info" />

          <div v-if="product.variations" class="ecom__switcher">
            <!-- BEGIN VARIATIONS (always 0 for bundles but we leave the possibility open) -->
            <template v-for="variation in product.variations">
              <!-- BEGIN PRODUCTS (devices that comprise bundle) -->
              <div
                v-for="(property, propertyKey, index) in variation.properties"
                :key="index"
                :class="'ecom__switcher-item ecom__switcher-item--'"
              >
                <!--BEGIN SWITCHER -->
                <template v-if="property.variations.length > 1">
                  <h2 class="ecom__switcher-product-name">{{ property.title }}</h2>
                  <h3 class="ecom__switcher-title">
                    {{ property.variation_switcher_text }}:
                    <span
                      v-if="property.variations[activeDevices[propertyKey]].properties.id !== 'volume' &&
                      property.variations[activeDevices[propertyKey]].properties.id !== 'country'"
                    >
                      {{ property.variations[activeDevices[propertyKey]].properties.label }}
                    </span>
                  </h3>


                  <div class="ecom__switcher-dots">
                    <label
                      v-for="(variation, key, index) in property.variations"
                      :key="index"
                      :style="{ 'background-color': variation.properties.color }"
                      :class="'ecom__switcher-dot ecom__switcher-dot--' + variation.id"
                    >
                      <input
                        type="radio"
                        :name="property.id + instance"
                        @change="
                        calculateCombination(
                          propertyKey,
                          variation.id,
                          key,
                          parseFloat(variation.price.original.number)
                        )
                      "
                        :class="'id' + variation.id"
                        :checked="key === 0"
                      />
                      <span
                        v-if="variation.properties.id === 'volume' || variation.properties.id === 'country'"
                        class="ecom__variation-name"
                      >
                        {{ variation.properties.label }}
                      </span>
                      <span v-else></span>
                    </label>
                  </div>
                </template>
                <!--END SWITCHER -->
              </div>
              <!-- END PRODUCTS -->
            </template>
            <!-- END VARIATIONS -->
          </div>

          <DeliveryEstimate
            :estimation="product.delivery_estimation"
            v-if="product.delivery_estimation.text"
            class="ecom__delivery"
          />

          <AddToCart
            :product="product"
            :activeVariation="activeVariation"
            :type="'bundle'"
            :bundlePrice="this.activePrices.reduce((a, b) => a + b)"
            :activeCombination="this.activeCombination"
            class="ecom__atc"
          />

          <div v-if="product.variations[activeVariation].special_notice" class="ecom__special-notes-wrap">
            <div class="ecom__special-notes ecom__special-notes--variation">
              <SpecialNotice
                :variation="product.variations[activeVariation]"
                v-if="product.variations[activeVariation].special_notice"
              />
            </div>
          </div>
          <div
            v-else-if="product.special_notice && !product.variations[activeVariation].special_notice"
            class="ecom__special-notes-wrap"
          >
            <div class="ecom__special-notes">
              <div
                v-for="(notice, key, index) in product.special_notice"
                :key="index"
                v-html="notice.notice_text"
                class="ecom__special-note"
              ></div>
            </div>
          </div>

          <Perks
            :variation="product.variations[activeVariation]"
            v-if="product.variations[activeVariation].perks"
            class="ecom__perks"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Loader from "./Loader.vue";
import AddToCart from "./AddToCart.vue";
import Slider from "./Slider.vue";
import Perks from "@/components/Perks";
import DeliveryEstimate from "@/components/DeliveryEstimate";
import Info from "@/components/Info";
import SpecialNotice from "./SpecialNotice";

export default {
  name: "BundleView",
  props: {
    product: {
      type: Object
    },
    instance: {
      type: String
    }
  },
  components: {
    Loader,
    AddToCart,
    Perks,
    Slider,
    DeliveryEstimate,
    Info,
    SpecialNotice
  },
  data() {
    return {
      activeVariation: 0, // Will always be 0 for Bundles
      activeDevices: [0, 0, 0, 0, 0, 0, 0, 0],
      activePrices: [0, 0, 0, 0, 0, 0, 0, 0],
      activeCombination: [],
      activeImages: [],
      buy: {}
    }
  },
  methods: {
    setInitialValues() {
      if (this.product.variations[this.activeVariation].properties.length) {
        let tempCombination = []
        for (let i = 0; i < this.product.variations[this.activeVariation].properties.length; i++) {
          if (this.product.variations[this.activeVariation].properties[i].variations.length !== 0) {
            tempCombination.push(this.product.variations[this.activeVariation].properties[i].variations[0].id)
            this.activePrices[i] = parseFloat(this.product.variations[this.activeVariation].properties[i].variations[0].price.original.number)
          }
        }
        this.activeCombination = tempCombination
        this.calculateCombination()
      }
    },
    calculateCombination(place, value, key, price) {
      this.activeDevices[place] = key
      this.activeCombination[place] = value
      this.activePrices[place] = price
      this.activeImages = []
      this.product.variations[this.activeVariation].images.forEach(image => {
        let difference = image.product_combo.filter(x => !this.activeCombination.includes(x));
        if (difference.length == 0) this.activeImages.push(image)
      });

      // In case of content fail prevent slider link breaking
      if (!this.activeImages.length) {
        this.activeImages = [{
          "badge": {
            "discount_badge": null,
            "promo_badge": null,
            "award_badge": null
          },
          "url": "https://assets.foreo.com/files/static/2021-01/slider404.png",
          "alt": "404"
        }]
      }
      this.$forceUpdate()
    }
  },
  beforeMount() {
    this.setInitialValues()
  }
};
</script>
